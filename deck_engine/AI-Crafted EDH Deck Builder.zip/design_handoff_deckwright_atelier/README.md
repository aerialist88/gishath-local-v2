# Handoff: The Deckwright's Atelier — UI for the deck_engine EDH pipeline

## Overview
A web + iPhone UI ("The Deckwright's Atelier") for `deck_engine`, an existing Python
nightly EDH deck-generation pipeline (select → ideate ×3 → synthesize → build →
validate/repair → optimize → synergy gate → price → deliver). The UI lets the user:
commission a deck (pick or roll a commander), watch the agent pipeline work live
with streaming detail, browse the finished deck, review past decks, handle failures,
and configure standing rules (budget, bracket, model tiers, newsletter).

Theme: a warm brass/parchment "artificer's workshop" — Urza/Mishra flavor, original
aesthetic (no WotC trade dress). AI agents are personified as apprentices at
workbenches; the validate/repair agent is "the Master Deckwright".

## About the Design Files
`Deck Artificer Explorations.dc.html` (+ `support.js`, `ios-frame.jsx`) is a
**design reference created in HTML** — a canvas of mocked screens, not production
code. The task is to **recreate these designs** in the real app's environment.
No frontend exists yet; the backend is the Python `deck_engine` codebase. Choose an
appropriate stack (e.g. a web app — React/Next or similar — that also works as a
responsive mobile web app or wraps to iOS; the phone mocks assume the same layout
at ~390pt width). The backend will need a thin API layer over `deck_engine`
(run status streaming, decklists, spend log, config).

The canvas contains three exploration turns. **Turn 1 options 1b/1c were rejected;
the chosen direction is 1a "The Atelier", developed in turns 2 and 3.**
Implement these screens (ids are anchors in the HTML file):

- `1a` — Live run, web (ideate stage: 3 parallel apprentice benches)
- `2a` — Home / commission, web
- `2b` — Finished deck, web
- `2c` — Live run, iPhone
- `2d` — Home, iPhone
- `3a` — Finished deck, iPhone
- `3b` — Live run, late stage (validate/repair loop), web
- `3c` — Failure state (spend cap halt), web
- `3d` — Guild rules (settings), web

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final intent —
recreate closely. Data shown (card names, prices, costs) is sample data; wire to
real pipeline output.

## Design Tokens

### Colors
- Page background (parchment): `#f3ead9`
- Card/panel background: `#faf4e6`; secondary panel: `#f8f1e1`
- Header gradient: `linear-gradient(180deg,#efe3cc,#ead9ba)`
- Primary text (ink): `#2c2113`; secondary: `#6b5530`; tertiary/muted: `#8a6d3a`; faint: `#a98f5a`; label caps: `#9a7c42`
- Brass accent: `#c8a15a`; brass dark: `#a97f35`; brass border: `#b09150`; panel border: `#c8ab6d` / `#d5bc85` / `#d9c69a`; track: `#ead9ba`; rail idle: `#dcc99e`
- Dark plaque (inverse): bg `#40300f`, text `#e8c887`, label `#c8a15a`
- Brass button gradient: `linear-gradient(180deg,#c8a15a,#a97f35)`, border `#7a5c22`, text `#241a08`
- Success/OK: `#3f7a3a`
- Warning/error (rust): `#a3442a`; dark rust `#8a4a2a`; error panel bg `#f6ead9`; error dark plaque bg `#40230f` text `#e8c0a0`; error bar `#c96a2a`
- Price-flag (over per-card cap): rust `#a3442a` with `⚑`

### Typography
- Display serif: **Cormorant Garamond** (600/700; italic for flavor text) — titles, apprentice names, plaque headings, section card titles
- Body sans: **Source Sans 3** (400–700) — UI copy, labels, buttons
- Mono: **IBM Plex Mono** (400–600) — all numbers, costs, tokens, timestamps, model chips, ledger rows
- Label style: 10–12px, uppercase, letter-spacing 1.5–2.5px, color `#9a7c42`
- Scale (web): page titles 26–40px serif; plaque names 20–36px serif; body 13–14.5px; mono meta 10–12px. Phone: titles 17–21px serif, body 11–13px.

### Shape & depth
- Panel radius 10–14px; chips/buttons 8–10px; pills 999px
- Shadows subtle warm: `0 2px 6px rgba(120,90,30,.12)` panels, `0 2px 8px rgba(120,90,30,.15–.25)` plaques
- Dotted price leaders: `border-bottom:1px dotted #cbb37f` on a flex filler
- Card-art placeholders: diagonal stripes `repeating-linear-gradient(45deg,#e6d7b8,#e6d7b8 6px,#ddcba6 6px,#ddcba6 12px)`, 1px `#b09150` border — replace with Scryfall card art (see Assets)

### Signature motifs
- Guild seal logo: concentric brass circles (radial gradient `#e8c887→#b98c3e`, inner ring on parchment)
- Blinking caret on live streams: 7×13px block `#b98c3e`, `step-end` blink 1s
- Pulsing status text: opacity .55↔1, 2s ease-in-out
- "Ledger" rows: `✓` green + stage name + dotted leader + mono meta
- Model chip: mono 9.5px on `#40300f` bg, `#e8c887` text

## Screens

### 2a — Home / Commission (web)
- Header: seal + "The Deckwright's Atelier" serif 22px + nav (Commission / Workshop / Gallery / Guild rules; active = `rgba(154,116,47,.18)` bg pill) + right mono meta "night 47 · next nightly run 02:00"
- Hero (2-col grid, 1fr/380px): eyebrow "Commission No. 48"; serif 40px "What shall the guild artifice tonight?"; commander search input (inset shadow, parchment) + brass button "Let the guild choose" with a drawn die glyph (bordered square + 3 dots — do NOT use the ⚄ character, it renders inconsistently); three knob cards (Bracket / Budget / Colors) with label/value/hint; dark CTA "Begin the commission →" (`#40300f` bg, `#e8c887` text, serif 19px)
- Right: "Fresh from the forge — last night" plaque with commander art, name, price, run stats, "Open in the gallery →" ghost button
- Below: gallery shelf, 5-col grid of deck cards (art crop, serif name, archetype, mono date+price)

### 1a — Live run, ideate stage (web)
- Header adds right-aligned mono stats: Elapsed / Spend / Calls (label caps + 15px values)
- Commission plaque: commander art 86×120, eyebrow "Tonight the guild artifices", serif 34px commander name, italic serif concept line, archetype pills
- Stage gauge: 8 nodes (Select, Ideate, Synthesize, Build, Validate, Optimize, Price, Deliver) — done = brass fill + ✓; active = dark fill + ⚙ glyph; todo = outline + number; connected by 2px rails (done rails brass)
- "The apprentices convene — three ideation benches, working in parallel": 3-col grid of apprentice cards. Each: header (initial in brass ring, serif name e.g. "Apprentice Cog", caps angle line "Angle · sacrifice engines", model chip), mono streaming text with blinking caret (min-height 118px), footer row "⚙ streaming — turn 2" (pulsing) + "1,204 tok · $0.0312"
- Ledger panel: completed calls (select, mechanic tokens, edhrec pool fetch, price gate)

### 3b — Live run, validate/repair stage (web)
Same header/gauge (Validate active with ⚒ glyph). Main 2-col (1fr/340px):
- Single "Master Deckwright" bench card (same anatomy as apprentice card; subhead "Repair pass 1 of 2 · fixing 3 flaws"), streaming repair reasoning
- "Inspection ledger" error panel: rust header bar (`#8a4a2a` bg), rows = flaw kind (mono caps, e.g. COLOR IDENTITY / HALLUCINATION / SINGLETON) + card + reason + fix ("→ Deadly Rollick" in green, or "⚒ mending…" pending). Flaw kinds map to `deck_engine` validation: color-identity violation, Scryfall hallucination, singleton duplicate; also banned cards.
- Right rail: night-so-far ledger (⚠ row for validate, ⚒ for running repair) + dark "Crucible spend" plaque with progress bar vs cap

### 3c — Failure state: spend cap halt (web)
- Header switches to rust: border `#a3442a`, seal in copper tones, status "Halted at 03:41", warning chip "The crucible ran dry — spend cap reached"
- Left: serif headline "The work stopped at the Optimize bench.", explainer; "Preserved — last good decklist" panel (commander, "100 cards · legal ✓ · validated 03:22 · pre-optimize · unpriced") with 3 stacked actions: brass "Resume — raise cap to $7.50", ghost "Price & deliver as-is", rust ghost "Abandon commission"
- "Where the crucible burned": horizontal spend-by-stage bars, offending stage in `#c96a2a`
- Right: full-night ledger (✓/✕/·) + dry crucible plaque (rust, 100% bar) + italic note: halt still sends the report email marked incomplete (matches `run.py` fail-closed behavior)

### 2b — Finished deck (web)
- Plaque header: art 92×128, "Commission No. 47 · Delivered 06:42", serif 36px name, italic concept, pills (Bracket 3 / Legal ✓ / Synergy gate passed); right: mono 26px "SGD 231.40", note "cheapest across 15 stores · 2 cards over cap, flagged", buttons Moxfield .txt (brass) / .xlsx / Resend email
- Tabs: Decklist / Breakdown / Gameplan / Stats (3px brass underline on active) — mirror the xlsx sheets
- Body 2-col (1fr/300px): decklist in 2 CSS columns grouped by role (serif role header + count, 2px brass underline; rows = card name, dotted leader, mono price; over-cap prices rust + ⚑)
- Right rail: mana-curve bar chart (brass gradient bars, mono axis labels, "avg CMC 2.87 · 36 lands"); "Priciest inclusions" list; dark "The artificers' note" plaque (italic serif gameplan quote + mono run cost line)

### 2c / 2d / 3a — iPhone screens
Same system compressed to ~390pt. Key adaptations:
- Headers need safe-area top padding (mocks use 58px) under the status bar
- 2c live run: compact stage strip = 8 equal segments, 4px bars (done brass, active dark, todo `#dcc99e`) with 3-letter caps labels; apprentice cards stack vertically, streams clamped to ~64px; footer dashed chip "⚙ ideate · 3 benches working · 7/~14 calls"
- 2d home: dark-banded "Delivered this morning" plaque (dark caps bar + art + name + price + View deck / Moxfield buttons), "Commission a deck →" dark CTA + square brass die button, gallery as compact rows
- 3a deck view: back link "‹ Gallery", plaque header, segmented control (List / Breakdown / Gameplan / Stats — active segment raised on `#faf4e6`), curve strip card, collapsible role sections (▾/▸), sticky-ish export bar (Moxfield .txt brass / Share ghost)

### 3d — Guild rules / settings (web)
Top-right brass "Inscribe changes" save button. 2-col grid of panels:
- **The purse**: 3 slider rows — Deck budget (SGD 250), Per-card cap (SGD 40), Crucible cap ($5.00 API spend) — brass track fill, dark knob
- **The bracket**: 5 selectable cards 1–5 (Exhibition/Core/Upgraded/Optimized/cEDH), active = brass gradient
- **The nightly bell**: toggles — Nightly commission (02:00), Exclude recent commanders (30 days), Resume chaining (off, experimental — maps to `DECK_ENGINE_RESUME_CHAINING`)
- **The workforce**: per-stage model tier picker (Select: haiku; Ideate ×3 / Synthesize: sonnet; Build: opus; Validate+repair / Optimize: sonnet) — selected chip dark, unselected outline
- **The courier**: master's email (full diagnostics) + newsletter BCC chips ("clean copy, no diagnostics") + italic note "Friends receive the deck and the tale — never the cost sheet." (maps to the two-send behavior in `emailer.py`)

## Interactions & Behavior
- **Live streaming**: apprentice/master bench text streams token-by-token (SSE/WebSocket over `claude_cli` output); blinking caret while streaming; footer turn/token/cost counters update live; header Elapsed/Spend/Calls tick
- **Stage gauge**: nodes flip done→active→todo as `run.py` progresses; ledger rows append as calls complete
- **Ideate**: exactly 3 parallel benches; when one finishes, its caret stops and footer becomes "packaging output… → N candidate cards"
- **Repair loop**: inspection-ledger rows flip from "⚒ mending…" to a green "→ Replacement" as the repair stream resolves; up to 2 repair passes
- **Failure**: any halt (spend cap, retries exhausted) lands on the 3c pattern with stage-appropriate copy; resume/deliver/abandon actions
- **Commission**: typed commander OR "guild's choice" roll (excludes last-30-days commanders); begins run and navigates to live view
- **Deck view**: role sections collapsible on phone; Moxfield .txt and .xlsx are downloads of the pipeline's existing exports
- **Run position persistence**: returning to the app mid-run resumes the live view at current state
- Buttons: darken ~6% on hover, brass buttons have pressed inset state. No other animations beyond caret blink and status pulse — the design is deliberately calm.

## State Management
- Run state machine: `idle → running(stage, substage) → delivered | halted(reason)` with per-call records `{stage, model, turns, tokens_in/out, cost_usd, duration}` (matches `claude -p` envelope: `num_turns`, `total_cost_usd`)
- Config: budget SGD, per-card cap, crucible cap USD, bracket 1–5, nightly time, exclusion window days, resume flag, per-stage model tier, emails
- Deck archive: list of past commissions with decklist, roles, prices, curve, gameplan, run diagnostics

## Assets
- Fonts: Google Fonts — Cormorant Garamond, Source Sans 3, IBM Plex Mono
- Card art: all art areas are striped placeholders; use Scryfall image URIs (`image_uris.art_crop` for shelves, `normal` for plaques) with the required attribution; cache per Scryfall guidelines
- No other binary assets; the guild seal and die glyph are drawn with CSS (keep as code or redraw as SVG)

## Files
- `Deck Artificer Explorations.dc.html` — all screens (anchors `#1a`–`#3d`); template markup + a logic class at the bottom containing all sample data arrays (stages, apprentices, ledgers, decklist roles, curve, settings values) — useful as seed/mock data
- `ios-frame.jsx` — device frame used for presentation only; not part of the product
- `support.js` — canvas runtime; ignore
- `screenshots/` — static PNG of each screen, for quick reference without opening the HTML:
  - `1a-live-run-ideate.png`, `2a-home-commission.png`, `2b-finished-deck-web.png`,
    `2c-live-run-iphone.png`, `2d-home-iphone.png`, `3a-finished-deck-iphone.png`,
    `3b-live-run-validate-repair.png`, `3c-failure-spend-cap.png`, `3d-guild-rules-settings.png`
